﻿namespace Jatek_Lib
{
    public class Class1
    {
        public string Kezdoszoveg (string nev)
        {
            return $"Hello {nev} !\nA Dungeon-Rush-ban egy nehéz szobákból álló pályán kell egyre feljebb küzdened magad a fő ellenfélig.\nUtad során találkozhatsz kereskedőkkel és ládákkal, amik segítségedre lehetnek a játék során.\nSok sikert {nev}!\nKezdődik a játék!";
        }

        
    }
}
