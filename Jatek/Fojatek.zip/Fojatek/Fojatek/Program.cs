﻿using Jatek_Lib;

Console.WriteLine("Köszöntünk a Dungeon-Rush játékban!");
Console.WriteLine();
Console.Write("Kérem adja meg a főhős nevét: ");
string fohosnev = Console.ReadLine();
Console.WriteLine();
Console.WriteLine();